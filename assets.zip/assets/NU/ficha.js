
$(document).ready(function () {


    //turn to inline mode  /popup
    $.fn.editable.defaults.mode = 'inline';
    
    $.fn.editableform.buttons = '<button type="submit" class="btn btn-info editable-submit"><i class="fa fa-fw fa-check"></i></button>' + '<button type="button" class="btn editable-cancel"><i class="far fa-window-close"></i></button>' ;
	    
    
    
    $('#username').editable({
    emptytext: 'Necessário'
    });
    $('#perfilFacebook').editable({
    emptytext: 'Necessário'
    });
    $('#perfilInstagram').editable({
    emptytext: 'Necessário'
    });
    $('#perfilTwitter').editable({
    emptytext: 'Necessário'
    });



    var consulados = [];
    $.each({"RE": "Recife", "DF": "Brasília", "RS": "Porto Alegre", "SP": "São Paulo"}, function(k, v) {
        consulados.push({id: k, text: v});
    }); 
    $('#consulado').editable({
        source: consulados,
        select2: {
            width: 200,
            placeholder: 'Selecione o consulado',
            allowClear: true
        } 
    });   


    $('#consulado').editable({
        prepend: "not selected",
        source: [
            {value: 1, text: 'Recife'},
            {value: 2, text: 'Brasília'},
            {value: 2, text: 'Porto Alegre'},
            {value: 2, text: 'São Paulo'}
        ],
        display: function(value, sourceData) {
             var colors = {"": "gray", 1: "green", 2: "blue"},
                 elem = $.grep(sourceData, function(o){return o.value == value;});
                 
             if(elem.length) {    
                 $(this).text(elem[0].text).css("color", colors[value]); 
             } else {
                 $(this).empty(); 
             }
        }   
    });    










});
